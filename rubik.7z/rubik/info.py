#https://wzd0029-rubik.mybluemix.net


def _info(parms):
    result = {'status': 'wzd0029'}
    return result
