s = "sdfsdfq34sd?"
print(s.isalnum())