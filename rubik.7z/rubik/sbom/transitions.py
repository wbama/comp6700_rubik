class Transition(object):

    def __init__(self, params):
        pass