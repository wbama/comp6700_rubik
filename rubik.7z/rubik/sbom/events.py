class Event(object):

    def __init__(self, params):
        pass
        