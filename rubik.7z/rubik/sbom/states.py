class State(object):

    def __init__(self, params):
        pass