#from test.test_set import cube

class Cube:
    def __init__(self, cube_str, rotate_str, op_str):
        self.cube_str = cube_str
        self.rotate_str = rotate_str
        self.op_str = op_str
        

        

    
        
    

cube1 = Cube("a", "b", "c")